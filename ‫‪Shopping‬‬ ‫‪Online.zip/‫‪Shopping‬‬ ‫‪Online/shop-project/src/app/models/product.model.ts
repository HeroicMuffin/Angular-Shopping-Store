export class ProductModel {
    public constructor(
        public productName?: string,
        public category?: string,
        public price?: number,
        public picture?: string
    ) { }
}